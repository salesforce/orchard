alter table "resources"
add column "terminate_after" DOUBLE PRECISION NOT NULL DEFAULT 8.0;
