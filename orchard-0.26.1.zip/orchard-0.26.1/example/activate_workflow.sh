#!/usr/bin/env bash

http PUT http://localhost:9001/v1/workflow/$1/activate
