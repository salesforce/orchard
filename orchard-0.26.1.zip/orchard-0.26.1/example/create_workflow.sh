#!/usr/bin/env bash

http http://localhost:9001/v1/workflow < data/sample_workflow.json
