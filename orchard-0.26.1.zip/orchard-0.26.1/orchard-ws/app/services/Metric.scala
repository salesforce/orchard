/*
 * Copyright (c) 2022, salesforce.com, inc.
 * All rights reserved.
 * SPDX-License-Identifier: BSD-3-Clause
 * For full license text, see the LICENSE file in the repo root or https://opensource.org/licenses/BSD-3-Clause
 */

package services

import java.io.StringWriter
import javax.inject.{Inject, Singleton}

import scala.concurrent.{ExecutionContext, Future}

import io.prometheus.client._
import io.prometheus.client.exporter.common.TextFormat
import io.prometheus.client.hotspot.DefaultExports

trait Metric {

  def incrementStatusCount(status: String): Unit

  def startApiTimer(labels: String*): () => Unit

  def collect: Future[String]

  def onCollect(): Unit

}

@Singleton
class PrometheusMetric @Inject() (implicit ec: ExecutionContext) extends Metric {

  DefaultExports.initialize()
  // clear the default registry uppon initialization to make it easier to work with play-plugin
  // auto recompile
  CollectorRegistry.defaultRegistry.clear()

  private val httpStatusCount: Counter = Counter.build
    .name("http_requests_total")
    .help("Total HTTP Requests Count")
    .labelNames("status")
    .register

  private val apiLatency: Summary = Summary
    .build()
    .name("apiLatencySummary")
    .labelNames("path", "arguments", "method")
    .help("Profile API response time summary")
    .quantile(0.5d, 0.001d)
    .quantile(0.95d, 0.001d)
    .quantile(0.99d, 0.001d)
    .register

  override def incrementStatusCount(status: String): Unit = {
    httpStatusCount.labels(status).inc()
  }

  override def startApiTimer(labels: String*): () => Unit = {
    val timer = apiLatency.labels(labels: _*).startTimer()
    val callback = () => timer.close
    callback
  }

  // Get metrics from the local prometheus collector default registry
  override def collect: Future[String] = Future {
    val writer = new StringWriter()
    TextFormat.write004(writer, CollectorRegistry.defaultRegistry.metricFamilySamples())
    writer.toString
  }

  override def onCollect(): Unit = {}

}
