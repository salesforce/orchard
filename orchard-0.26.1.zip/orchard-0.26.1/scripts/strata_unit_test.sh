#!/bin/bash

cat << 'EOF' > /root/.sbt/repositories
[repositories]
  local
  my-maven-proxy-central: https://sfcirelease.sfci.buildndeliver-s.aws-esvc1-useast2.aws.sfdc.is/nexus/service/local/repositories/central/content/
  my-maven-proxy-releases: https://sfcirelease.sfci.buildndeliver-s.aws-esvc1-useast2.aws.sfdc.is/nexus/service/local/repositories/releases/content/
  my-maven-proxy-thirdparty: https://sfcirelease.sfci.buildndeliver-s.aws-esvc1-useast2.aws.sfdc.is/service/local/repositories/thirdparty/content/
  nexus-plugins-ivy: https://sfcirelease.sfci.buildndeliver-s.aws-esvc1-useast2.aws.sfdc.is/nexus/content/repositories/sbt-plugin-releases/, [organization]/[module]/(scala_[scalaVersion]/)(sbt_[sbtVersion]/)[revision]/[type]s/[artifact](-[classifier]).[ext]
  kruxmvn-releases: https://ops0-artifactrepo1-0-prd.data.sfdc.net/artifactory/strata-blobs/mc-einstein/kruxmvn-releases/
EOF

cat << EOF > /root/.ivy2/.credentials
  realm=Sonatype Nexus Repository Manager
  host=sfcirelease.sfci.buildndeliver-s.aws-esvc1-useast2.aws.sfdc.is
  user=${NEXUS_USERNAME}
  password=${NEXUS_PASSWORD}
EOF

cat << EOF > /root/.sbt/1.0/global.sbt
  credentials += Credentials("Sonatype Nexus Repository Manager", "sfcirelease.sfci.buildndeliver-s.aws-esvc1-useast2.aws.sfdc.is", "${NEXUS_USERNAME}", "${NEXUS_PASSWORD}")
EOF

export SBT_CREDENTIALS="/root/.ivy2/.credentials"

sbt -Dsbt.color=false clean dist
